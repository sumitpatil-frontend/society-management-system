import { useEffect, useState } from "react";
import { getRequests, updateRequestStatus } from "../utils/storage";
import StatusChip from "../components/StatusChip";

import {
  Card,
  CardContent,
  Typography,
  MenuItem,
  TextField,
  Box
} from "@mui/material";

import { toast } from "react-toastify";

export default function AdminDashboard() {
  const [requests, setRequests] = useState([]);

  useEffect(() => {
    setRequests(getRequests());
  }, []);

  const changeStatus = (id, newStatus) => {
    updateRequestStatus(id, newStatus);
    toast.info(`Status updated to "${newStatus}"`);
    setRequests(getRequests());
  };

  return (
    <div style={{ padding: "20px" }}>
      <Typography variant="h4" sx={{ mb: 3 }}>
        Admin Dashboard
      </Typography>

      {requests.map((req) => (
        <Card key={req.id} sx={{ mb: 2, borderRadius: "12px", boxShadow: 3 }}>
          <CardContent>
            <Typography variant="h6">{req.title}</Typography>

            <Typography sx={{ mt: 1 }}>
              <b>Category:</b> {req.category}
            </Typography>

            <Box sx={{ mt: 1 }}>
              <StatusChip status={req.status} />
            </Box>

            <Typography sx={{ mt: 1 }} variant="body2">
              <b>Date:</b> {req.date}
            </Typography>

            <TextField
              select
              fullWidth
              label="Update Status"
              value={req.status}
              onChange={(e) => changeStatus(req.id, e.target.value)}
              sx={{ mt: 2 }}
            >
              <MenuItem value="pending">Pending</MenuItem>
              <MenuItem value="in-progress">In Progress</MenuItem>
              <MenuItem value="completed">Completed</MenuItem>
            </TextField>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
