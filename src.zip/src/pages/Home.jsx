import { Typography } from "@mui/material";

export default function Home() {
  return (
    <div style={{ padding: "20px" }}>
      <Typography variant="h4">Welcome to Maintainex</Typography>
      <Typography sx={{ mt: 1 }}>
        Your society maintenance request system.
      </Typography>
    </div>
  );
}
