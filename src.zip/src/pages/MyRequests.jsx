import { useEffect, useState } from "react";
import { getRequests } from "../utils/storage";
import { Link } from "react-router-dom";
import StatusChip from "../components/StatusChip";
import { Card, CardContent, Typography, Button } from "@mui/material";

export default function MyRequests() {
  const [requests, setRequests] = useState([]);

  useEffect(() => {
    setRequests(getRequests());
  }, []);

  return (
    <div style={{ padding: "20px" }}>
      <Typography variant="h4" sx={{ mb: 3 }}>
        My Requests
      </Typography>

      {requests.length === 0 && (
        <Typography>No requests found.</Typography>
      )}

      {requests.map((req) => (
        <Card key={req.id} sx={{ mb: 2, borderRadius: "12px", boxShadow: 3 }}>
          <CardContent>
            <Typography variant="h6">{req.title}</Typography>
            <Typography sx={{ mt: 1 }}>Category: {req.category}</Typography>
            <div style={{ marginTop: "10px" }}>
              <StatusChip status={req.status} />
            </div>

            <Typography sx={{ mt: 1 }} variant="body2">
              Date: {req.date}
            </Typography>

            <Button component={Link} to={`/request/${req.id}`} variant="contained" sx={{ mt: 2 }}>
              View Details
            </Button>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
