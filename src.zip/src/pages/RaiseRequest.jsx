import { useState } from "react";
import { v4 as uuidv4 } from "uuid";
import { addRequest } from "../utils/storage";
import { TextField, Button, MenuItem, Card, CardContent, Typography } from "@mui/material";
import { toast } from "react-toastify";

export default function RaiseRequest() {
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("");
  const [description, setDescription] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!title || !category || !description) {
      toast.error("All fields are required!");
      return;
    }

    const newRequest = {
      id: uuidv4(),
      title,
      category,
      description,
      status: "pending",
      date: new Date().toLocaleString(),
    };

    addRequest(newRequest);
    toast.success("Request submitted!");

    setTitle("");
    setCategory("");
    setDescription("");
  };

  return (
    <div style={{ padding: "20px" }}>
      <Card sx={{ maxWidth: 500, margin: "auto", mt: 3 }}>
        <CardContent>
          <Typography variant="h5" sx={{ mb: 2 }}>
            Raise a Maintenance Request
          </Typography>

          <form onSubmit={handleSubmit}>
            <TextField
              fullWidth
              label="Issue Title"
              variant="outlined"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              sx={{ mb: 2 }}
            />

            <TextField
              select
              fullWidth
              label="Select Category"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              sx={{ mb: 2 }}
            >
              <MenuItem value="Water">Water</MenuItem>
              <MenuItem value="Electric">Electric</MenuItem>
              <MenuItem value="Cleaning">Cleaning</MenuItem>
              <MenuItem value="Lift">Lift</MenuItem>
            </TextField>

            <TextField
              fullWidth
              label="Description"
              multiline
              rows={4}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              sx={{ mb: 2 }}
            />

            <Button variant="contained" color="primary" fullWidth type="submit">
              Submit Request
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
