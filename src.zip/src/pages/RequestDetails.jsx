import { useParams } from "react-router-dom";
import { getRequestById } from "../utils/storage";
import StatusChip from "../components/StatusChip";
import { Card, CardContent, Typography } from "@mui/material";

export default function RequestDetails() {
  const { id } = useParams();
  const request = getRequestById(id);

  if (!request) return <h2 style={{ padding: "20px" }}>Request not found.</h2>;

  return (
    <div style={{ padding: "20px" }}>
      <Typography variant="h4">Request Details</Typography>

      <Card sx={{ mt: 3, maxWidth: 500 }}>
        <CardContent>
          <Typography variant="h6">{request.title}</Typography>

          <Typography sx={{ mt: 1 }}>
            <b>Category:</b> {request.category}
          </Typography>

          <div style={{ marginTop: "10px" }}>
            <StatusChip status={request.status} />
          </div>

          <Typography sx={{ mt: 1 }}>
            <b>Date:</b> {request.date}
          </Typography>

          <Typography sx={{ mt: 2 }}>
            <b>Description:</b><br />
            {request.description}
          </Typography>
        </CardContent>
      </Card>
    </div>
  );
}
