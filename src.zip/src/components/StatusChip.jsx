export default function StatusChip({ status }) {
  const getColor = () => {
    switch (status) {
      case "pending":
        return { background: "#ffecb3", color: "#b26a00" };
      case "in-progress":
        return { background: "#bbdefb", color: "#003c8f" };
      case "completed":
        return { background: "#c8e6c9", color: "#1b5e20" };
      default:
        return { background: "#eee", color: "#555" };
    }
  };

  return (
    <span
      style={{
        padding: "5px 12px",
        borderRadius: "20px",
        fontSize: "12px",
        fontWeight: "bold",
        textTransform: "capitalize",
        ...getColor(),
      }}
    >
      {status}
    </span>
  );
}
