import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import RaiseRequest from "./pages/RaiseRequest";
import MyRequests from "./pages/MyRequests";
import AdminDashboard from "./pages/AdminDashboard";
import RequestDetails from "./pages/RequestDetails";
import Navbar from "./components/Navbar";

import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

function App() {
  return (
    <Router>
      <Navbar />

      <ToastContainer position="top-right" theme="colored" />

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/raise" element={<RaiseRequest />} />
        <Route path="/my-requests" element={<MyRequests />} />
        <Route path="/admin" element={<AdminDashboard />} />
        <Route path="/request/:id" element={<RequestDetails />} />
      </Routes>
    </Router>
  );
}

export default App;
