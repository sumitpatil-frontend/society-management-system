const STORAGE_KEY = "maintainex_requests";

export function getRequests() {
  const data = localStorage.getItem(STORAGE_KEY);
  return data ? JSON.parse(data) : [];
}

export function saveRequests(requests) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(requests));
}

export function addRequest(newRequest) {
  const existing = getRequests();
  existing.push(newRequest);
  saveRequests(existing);
}

export function getRequestById(id) {
  return getRequests().find((r) => r.id === id);
}

export function updateRequestStatus(id, newStatus) {
  const all = getRequests();
  const updated = all.map((req) =>
    req.id === id ? { ...req, status: newStatus } : req
  );
  saveRequests(updated);
}
